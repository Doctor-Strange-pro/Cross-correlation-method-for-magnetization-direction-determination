function [RTP,TGMP,VG,TG] = cal_RTP_TGMP_VG_TG(delta_T,I0,D0,I_m,D_m)
T = expand(delta_T,0.5);
[yn,xn] = size(delta_T);
[Yn,Xn] = size(T);
exn = (Xn-xn)/2;
eyn = (Yn-yn)/2;
M = ceil((Yn+1)/2);
N = ceil((Xn+1)/2);
Nex = floor((Xn-1)/2);
dkx = 1/(Yn); dky = 1/(Xn);
u = [0:M-1 -(Yn-M):-1]*dkx;
v = (0:N-1)*dky;
[u,v]=meshgrid(u,v);

alpha1=cos(I0/180*pi)*cos((D0)/180*pi);
beida1=cos(I0/180*pi)*sin((D0)/180*pi);
gama1=sin(I0/180*pi);
alpha2=cos(I_m/180*pi)*cos((D_m)/180*pi);
beida2=cos(I_m/180*pi)*sin((D_m)/180*pi);
gama2=sin(I_m/180*pi);
q0=2*pi*(1i*(alpha1*u+beida1*v)+gama1*(u.*u+v.*v).^0.5);
q1=2*pi*(1i*(alpha2*u+beida2*v)+gama2*(u.*u+v.*v).^0.5);

f1=2i*pi*u;
f2=2i*pi*v;
f3=2*pi*(u.*u+v.*v).^0.5;
f4=(2*pi*(u.*u+v.*v).^0.5)./((q0.*q1)+1e-8);

S=fft2(T);
Sp1 = S(1:N,:).*f4.*f3;
Sp2 = S(1:N,:).*f4.*f3.*f1;
Sp3 = S(1:N,:).*f4.*f3.*f2;
Sp4 = S(1:N,:).*f4.*f3.*f3;
Sp5 = S(1:N,:).*f4.*f1;
Sp6 = S(1:N,:).*f4.*f2;
Sp11 = [Sp1;flipud(conj(Sp1(2:1+Nex,1))) rot90(conj(Sp1(2:1+Nex,2:end)),2)];
Sp21 = [Sp2;flipud(conj(Sp2(2:1+Nex,1))) rot90(conj(Sp2(2:1+Nex,2:end)),2)];
Sp31 = [Sp3;flipud(conj(Sp3(2:1+Nex,1))) rot90(conj(Sp3(2:1+Nex,2:end)),2)];
Sp41 = [Sp4;flipud(conj(Sp4(2:1+Nex,1))) rot90(conj(Sp4(2:1+Nex,2:end)),2)];
Sp51 = [Sp5;flipud(conj(Sp5(2:1+Nex,1))) rot90(conj(Sp5(2:1+Nex,2:end)),2)];
Sp61 = [Sp6;flipud(conj(Sp6(2:1+Nex,1))) rot90(conj(Sp6(2:1+Nex,2:end)),2)];
r1 = ifft2(Sp11);
r2 = ifft2(Sp21);
r3 = ifft2(Sp31);
r4 = ifft2(Sp41);
r5 = ifft2(Sp51);
r6 = ifft2(Sp61);
s1 = real(r1(exn+1:exn+xn,eyn+1:eyn+yn));
s2 = real(r2(exn+1:exn+xn,eyn+1:eyn+yn));
s3 = real(r3(exn+1:exn+xn,eyn+1:eyn+yn));
s4 = real(r4(exn+1:exn+xn,eyn+1:eyn+yn));
s5 = real(r5(exn+1:exn+xn,eyn+1:eyn+yn));
s6 = real(r6(exn+1:exn+xn,eyn+1:eyn+yn));
RTP = s1;
VG = s4;
TG = sqrt(s2.^2+s3.^2+s4.^2);
TGMP = sqrt(s1.^2+s5.^2+s6.^2);
end