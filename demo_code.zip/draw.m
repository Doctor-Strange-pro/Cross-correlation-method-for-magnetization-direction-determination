function [] = draw(I_true,D_true)
plot(I_true,D_true,'blackO','MarkerSize',6,'LineWidth',2);alpha(0.5)
r = 10;
xc = I_true;
yc = D_true;
theta = linspace(0,2*pi);
x = r*cos(theta) + xc;
y = r*sin(theta) + yc;
plot(x,y,'black')
r = 5;
theta = linspace(0,2*pi);
x = r*cos(theta) + xc;
y = r*sin(theta) + yc;
plot(x,y,'black')
axis equal
r = 15;
theta = linspace(0,2*pi);
x = r*cos(theta) + xc;
y = r*sin(theta) + yc;
plot(x,y,'black');axis([I_true-20 I_true+20 D_true-20 D_true+20]);grid on
xl=xlabel('Inclination(degree)','FontSize',12);yl=ylabel('Deflection(degree)','FontSize',12);
set(xl,'Interpreter','latex');
set(yl,'Interpreter','latex');
set(gca,'FontSize',12,'Fontname', 'Times New Roman');
end