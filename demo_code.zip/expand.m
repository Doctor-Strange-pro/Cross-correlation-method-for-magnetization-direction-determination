function output = expand(input,Expansion_ratio)
[xn,yn] = size(input);
exnp = Expansion_ratio;
eynp = Expansion_ratio;
exn = ceil(exnp*xn);
eyn = ceil(eynp*yn);
glt=cos((exn:-1:1)'/exn*pi/2).*cos((eyn:-1:1)/eyn*pi/2)*input(1,1);
gtt=cos((exn:-1:1)'/exn*pi/2)*input(1,:);
grt=cos((1:exn)'/exn*pi/2)*cos((eyn:-1:1)/eyn*pi/2)*input(1,end);
gll=input(:,1)*cos((eyn:-1:1)/eyn*pi/2);
gcc=input;
grr=input(:,end)*cos((1:eyn)/eyn*pi/2);
glb=cos((exn:-1:1)'/exn*pi/2)*cos((1:eyn)/eyn*pi/2)*input(end,1);
gbb=cos((1:exn)'/exn*pi/2)*input(end,:);
grb=cos((1:exn)'/exn*pi/2)*cos((1:eyn)/eyn*pi/2)*input(end,end);
output=[glt gtt grt;gll gcc grr;glb gbb grb];
end