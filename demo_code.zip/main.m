% ************************************************************************%
%    Magnetization Direction Determination via the Correlation between
%  the Reduction-to-pole and the Total Gradient of the Magnetic Potential.
% ************************************************************************%
%                                AUTHORS
%
% ************************************************************************%
% Tested using Matlab 2022b under Windows 10 operation system
% ************************************************************************%

clear;clc
% load total field anomaly of a dip soure with remanance.
load('delta_TR.mat')
% the inclination and the declination of geomagnetic field.
I0=45; D0=0;
% the inclination and the declination of source magnetization.
I_m=30; D_m=40;
% total magnetization direction estimation
ite_number = 10; % iteration number of tests
% estimated inclinations and declinations of six different methods
resx = zeros(6,ite_number);
resy = zeros(6,ite_number);
% sampling interval of tentative inclinations and declinations is 1 degree
dim_inc = 1; dim_dec = 1;
fwait = waitbar(0,'Please wait...');
for p=1:ite_number
    % calculate TMA, Q, L, NSS from total field anomaly
    % and add Add white Gaussian noise to signal
    SNR=24; % the SNR of added white Gaussian noise
    delta_T=awgn(delta_TR,SNR,'measured'); % 5% noise enrgy
    [TMA,Q,L,NSS] = cal_TMA_Q_L_NSS(delta_T,I0,90-D0);
    i=0;
    px=20;
    % sampling range of tentative inclinations and declinations
    INC1=I_m-px; INC2=I_m+px;
    DEC1=D_m-px; DEC2=D_m+px;
    % creat correlation coefficient matrix for tentative directions
    R1=ones(2*px/dim_inc+1,2*px/dim_dec+1);
    R2=R1;R3=R1;R4=R1;R5=R1;R6=R1;
    for inc=INC1:dim_inc:INC2
        i=i+1;
        j=0;
        for dec=DEC1:dim_dec:DEC2
            j=j+1;
            % calculate RTP, VG, TG, and TGMP under assumed direction
            [RTP,TGMP,VG,TG] = ...
                cal_RTP_TGMP_VG_TG(delta_T,I0,90-D0,inc,90-dec);
            % calculate correlation coefficients of different methods
            r1=corrcoef(RTP(:), Q(:)); % RTP-Q method
            R1(i,j)=r1(2);
            r2=corrcoef(RTP(:), TMA(:)); % RTP-TMA method
            R2(i,j)=r2(2);
            r3=corrcoef(RTP(:), NSS(:)); % RTP-NSS method
            R3(i,j)=r3(2);
            r4=corrcoef(RTP(:), L(:)); % RTP-L method
            R4(i,j)=r4(2);
            r5=corrcoef(VG(:), TG(:)); % VG-TG method
            R5(i,j)=r5(2);
            r6=corrcoef(RTP(:),TGMP(:)); % RTP-TGMP method
            R6(i,j)=r6(2);
        end
    end
    % find the direction corresponds to the max correlation coefficient
    x = INC1:dim_inc:INC2;
    y = DEC1:dim_dec:DEC2;
    [row1,col1]=find(R1==max(max(R1)));
    [row2,col2]=find(R2==max(max(R2)));
    [row3,col3]=find(R3==max(max(R3)));
    [row4,col4]=find(R4==max(max(R4)));
    [row5,col5]=find(R5==max(max(R5)));
    [row6,col6]=find(R6==max(max(R6)));
    id1=x(row1);dec1=y(col1);
    id2=x(row2);dec2=y(col2);
    id3=x(row3);dec3=y(col3);
    id4=x(row4);dec4=y(col4);
    id5=x(row5);dec5=y(col5);
    id6=x(row6);dec6=y(col6);
    resx(1,p)=id1(1);resy(1,p)=dec1(1);
    resx(2,p)=id2(1);resy(2,p)=dec2(1);
    resx(3,p)=id3(1);resy(3,p)=dec3(1);
    resx(4,p)=id4(1);resy(4,p)=dec4(1);
    resx(5,p)=id5(1);resy(5,p)=dec5(1);
    resx(6,p)=id6(1);resy(6,p)=dec6(1);
    waitbar(p/ite_number,fwait,'Calculating');
end
close(fwait)
%% display the total field anomaly and the source shape
figure('Name','Total field anomaly and source shape','NumberTitle','off');
x1=500;y1=500;z1=200;l1=300;w1=100;h1=100;
x2=500;y2=550;z2=300;l2=300;w2=100;h2=100;
x3=500;y3=600;z3=400;l3=300;w3=100;h3=100;
x4=500;y4=650;z4=500;l4=300;w4=100;h4=100;
[a,b,c]=meshgrid([0 1]);
p1=alphaShape(l1*a(:)-(l1/2-x1),w1*b(:)-(w1/2-y1),h1*c(:)-(h1/2-z1));
p2=alphaShape(l2*a(:)-(l2/2-x2),w2*b(:)-(w2/2-y2),h2*c(:)-(h2/2-z2));
p3=alphaShape(l3*a(:)-(l3/2-x3),w3*b(:)-(w3/2-y3),h3*c(:)-(h3/2-z3));
p4=alphaShape(l4*a(:)-(l4/2-x4),w4*b(:)-(w4/2-y4),h4*c(:)-(h4/2-z4));
plot(p1,'edgecolor','none')
hold on;
grid on
plot(p2,'edgecolor','none')
plot(p3,'edgecolor','none')
plot(p4,'edgecolor','none')
camlight('left')
imagesc([0 1000],[0 1000],delta_T);colormap jet;alpha(0.8)
set(gca,'zdir','reverse')
xlabel('Easting (m)');ylabel('Northing (m)');zlabel('Depth (m)');
axis([0 1000,0,1000,0,1000]);
%% display the estimated results of different method
figure('Name','Esitimated results with noise','NumberTitle','off');
mark_size=10;
subplot(2,3,1)
hold on; plot(resx(1,:),resy(1,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('RTP-Q')
subplot(2,3,2)
hold on; plot(resx(2,:),resy(2,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('RTP-TMA')
subplot(2,3,3)
hold on; plot(resx(3,:),resy(3,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('RTP-NSS')
subplot(2,3,4)
hold on; plot(resx(4,:),resy(4,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('RTP-L')
subplot(2,3,5)
hold on; plot(resx(5,:),resy(5,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('VG-TG')
subplot(2,3,6)
hold on; plot(resx(6,:),resy(6,:),'r.','MarkerSize',mark_size);
draw(I_m,D_m);title('RTP-TGMP')